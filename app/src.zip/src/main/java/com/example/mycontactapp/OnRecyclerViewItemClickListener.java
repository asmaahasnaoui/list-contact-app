package com.example.mycontactapp;

public interface OnRecyclerViewItemClickListener {
    void onItemClick(int contactId);
}
